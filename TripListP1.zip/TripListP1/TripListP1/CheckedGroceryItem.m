//
//  CheckedGroceryItem.m
//  TripListP1
//
//  Created by Armand Roelens on 4/2/15.
//  Copyright (c) 2015 CSE 394. All rights reserved.
//

#import "CheckedGroceryItem.h"

@implementation CheckedGroceryItem

@end
